package com.example.shopee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
